# Student-Attendance-Analysis-Dashboard
This project is about attendance analysis of CUDA(Centurion University Data Analytics) Domain which consists of 40 students and 5 subjects. It is a very interactive daashboard which filters donut charts and bar charts. I have created this dashboard using python for backend and streamlit library for frontend.

