import streamlit as st
def heading():
    st.markdown("""  
            
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
<div class="container-fluid">
    <div class="card shadow">
    
             
     ⚛ Analytics Dashboard | Python & Streamlit 
  </div>
</div>
 

 """, unsafe_allow_html=True)

 